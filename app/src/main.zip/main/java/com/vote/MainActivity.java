package com.vote;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;

import com.prmja.http.*;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.vote_page);

        setFullScreen();




    }


    private void setFullScreen(){
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }


    public void onClickSend(View view) {

        EditText Name = (EditText)findViewById(R.id.editName);



        String res ="";
        try {
            String[] params = {"name", Name.getText().toString(),"tel","Value2"};
            //Http Get Method
            res = prmja_com.Post("http://vote.product.in.ua/stat.php" , params);



        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        setContentView(R.layout.thanx);

        new CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }
            @Override
            public void onFinish() {

                setContentView(R.layout.vote_page);
            }
        }.start();




    }


    public void onClick_v1(View view) {

    }

    public void onClickShowForm(View view) {
        setContentView(R.layout.activity_main);
    }
}
